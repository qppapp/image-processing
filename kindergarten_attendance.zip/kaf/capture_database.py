import sqlite3
import cv2
import os
from tkinter import *
from tkinter import ttk, messagebox


root = Tk()
root.title("Create Dataset")
root.geometry("420x200")
root.configure(bg="#1f2933")   

style = ttk.Style()
style.theme_use("clam")
style.configure(
    "Main.TButton",
    font=("Segoe UI", 12),
    padding=6,
    foreground="white",
    background="#2563eb",
    borderwidth=0
)
style.map("Main.TButton", background=[("active", "#1d4ed8")])

style.configure(
    "Input.TLabel",
    font=("Segoe UI", 11),
    background="#1f2933",
    foreground="white"
)

style.configure(
    "Input.TEntry",
    fieldbackground="white"
)

root.columnconfigure(1, weight=1)

id_lbl = ttk.Label(root, text="Enter Your ID:", style="Input.TLabel")
name_lbl = ttk.Label(root, text="Enter Your Full Name:", style="Input.TLabel")
role_lbl = ttk.Label(root, text="Role:", style="Input.TLabel")

id_val = ttk.Entry(root, width=25)
name_val = ttk.Entry(root, width=25)

role_var = StringVar()
role_box = ttk.Combobox(
    root,
    textvariable=role_var,
    values=["child", "guardian"],
    state="readonly"
)
role_box.set("")

id_lbl.grid(row=0, column=0, sticky=E, padx=8, pady=6)
id_val.grid(row=0, column=1, sticky=E + W, padx=8, pady=6)

name_lbl.grid(row=1, column=0, sticky=E, padx=8, pady=6)
name_val.grid(row=1, column=1, sticky=E + W, padx=8, pady=6)

role_lbl.grid(row=2, column=0, sticky=E, padx=8, pady=6)
role_box.grid(row=2, column=1, sticky=E + W, padx=8, pady=6)

val1 = val2 = role_choice = None

def submit_e():
    global val1, val2, role_choice
    val1 = id_val.get().strip()
    val2 = name_val.get().strip()
    role_choice = (role_var.get() or "").lower()

    if not val1 or not val2:
        messagebox.showerror("Missing data", "Please enter both ID and full name.")
        return

    root.destroy()

submit = ttk.Button(
    root,
    text="Submit",
    style="Main.TButton",
    command=submit_e
)
submit.grid(row=3, column=0, columnspan=2, sticky=E + W, padx=8, pady=10)

root.mainloop()


if not val1 or not val2:
    raise SystemExit("Registration cancelled by user.")


BASE = os.getcwd()
DB_PATH = os.path.join(BASE, "database", "database.db")
DATASET_DIR = os.path.join(BASE, "dataset")
CASCADE_LOCAL = os.path.join(BASE, "cascades", "haarcascade_frontalface_default.xml")

if not os.path.exists(DB_PATH):
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    os.system('python "' + os.path.join(BASE, "sql.py") + '"')

conn = sqlite3.connect(DB_PATH)
c = conn.cursor()

def assure_dir(path):
    d = os.path.dirname(path)
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)

face_id = str(val1)
name = str(val2)

if role_choice == "child" or role_choice == "":
    c.execute(
        "INSERT OR REPLACE INTO students(UID,student_name,attendance) VALUES(?,?,?)",
        (face_id, name, 'Absent')
    )
    conn.commit()

if role_choice in ("child", "guardian"):
    c.execute(
        "INSERT OR REPLACE INTO people(UID,name,role) VALUES(?,?,?)",
        (face_id, name, role_choice)
    )
    conn.commit()

vid_cam = cv2.VideoCapture(0)

CASCADE = os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")
if not os.path.exists(CASCADE):
    CASCADE = CASCADE_LOCAL

face_detector = cv2.CascadeClassifier(CASCADE)

assure_dir(os.path.join(DATASET_DIR, "dummy"))

count = 0
TARGET_COUNT = 30

while True:
    ret, frame = vid_cam.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_detector.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
        count += 1

        out_path = os.path.join(DATASET_DIR, f"User.{face_id}.{count}.jpg")
        cv2.imwrite(out_path, gray[y:y + h, x:x + w])

    cv2.imshow('Capture Dataset', frame)

    if cv2.waitKey(100) & 0xFF == ord('q'):
        break
    elif count >= TARGET_COUNT:
        try:
            tmp = Tk()
            tmp.withdraw()
            messagebox.showinfo(
                "Success",
                f"Captured {TARGET_COUNT} images for ID: {face_id}"
            )
            tmp.destroy()
        except Exception:
            pass
        break

vid_cam.release()
cv2.destroyAllWindows()
conn.close()
