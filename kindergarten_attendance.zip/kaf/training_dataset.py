import os, cv2
import numpy as np
from PIL import Image

BASE = os.getcwd()
DATASET = os.path.join(BASE, 'dataset')              
TRAINER_DIR = os.path.join(BASE, 'trainer')
MODEL_PATH = os.path.join(TRAINER_DIR, 'trainer.yml')

try:
    CASCADE = os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")
    if not os.path.exists(CASCADE):
        CASCADE = os.path.join(BASE, 'cascades', 'haarcascade_frontalface_default.xml')
except Exception:
    CASCADE = os.path.join(BASE, 'cascades', 'haarcascade_frontalface_default.xml')

os.makedirs(TRAINER_DIR, exist_ok=True)

recognizer = cv2.face.LBPHFaceRecognizer_create(radius=1, neighbors=8, grid_x=8, grid_y=8)
detector = cv2.CascadeClassifier(CASCADE)

def preprocess_face(gray_roi):
    """Normalize contrast & size for stable training."""
    eq = cv2.equalizeHist(gray_roi)
    return cv2.resize(eq, (200, 200), interpolation=cv2.INTER_AREA)

def getImagesAndLabels(path):
    image_paths = [os.path.join(path, f) for f in os.listdir(path)]
    faceSamples, Ids = [], []
    for p in image_paths:
        if not p.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff')):
            continue
        parts = os.path.basename(p).split(".")
        if len(parts) < 3:
            continue
        try:
            Id = int(parts[1])
        except Exception:
            continue

        pilImage = Image.open(p).convert('L')
        g = np.array(pilImage, 'uint8')

        faces = detector.detectMultiScale(g, scaleFactor=1.2, minNeighbors=5, minSize=(80, 80))
        for (x, y, w, h) in faces:
            faceSamples.append(preprocess_face(g[y:y+h, x:x+w]))
            Ids.append(Id)

    return faceSamples, Ids

faces, Ids = getImagesAndLabels(DATASET)
if not faces:
    raise SystemExit("No faces found in dataset/. Capture images first (User.<UID>.<N>.jpg).")

recognizer.train(faces, np.array(Ids))
recognizer.write(MODEL_PATH)

print(f"Trained model: {MODEL_PATH}")
print(f"Total face samples: {len(faces)} | Unique IDs: {len(set(Ids))}")

msg_gui = os.path.join(BASE, "message_gui.py")
if os.path.exists(msg_gui):
    os.system(f'python "{msg_gui}"')
