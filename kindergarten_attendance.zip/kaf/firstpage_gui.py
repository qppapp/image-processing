from tkinter import *
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
import os, sqlite3 as sql

BASE = os.getcwd()

def _py(script):
    os.system(f'python "{os.path.join(BASE, script)}"')

def ensure_db():
    db = os.path.join(BASE, 'database', 'database.db')
    if not os.path.exists(db):
        os.makedirs(os.path.dirname(db), exist_ok=True)
        _py('sql.py')

root = Tk()
root.title("Attendance")
root.configure(background="#1f2933")
root.geometry("900x550")

style = ttk.Style()
style.theme_use("clam")
style.configure("Main.TButton", font=("Segoe UI", 14), padding=10,
                foreground="white", background="#2563eb", borderwidth=0)
style.map("Main.TButton", background=[("active","#1d4ed8")])
style.configure("Danger.TButton", font=("Segoe UI", 14), padding=10,
                foreground="white", background="#111827", borderwidth=0)
style.map("Danger.TButton", background=[("active","#1f2937")])
style.configure("Card.TFrame", background="#111827")
style.configure("Header.TLabel", font=("Segoe UI Semibold", 20),
                background="#111827", foreground="white")
style.configure("Title.TLabel", font=("Segoe UI Bold", 22),
                background="#1f2933", foreground="white")

title_lbl = ttk.Label(root, text="Face ID Attendance",
                      style="Title.TLabel")
title_lbl.grid(row=0, column=0, columnspan=2, sticky=EW, padx=20, pady=(20,10))

root.columnconfigure(0, weight=1)
root.columnconfigure(1, weight=1)

def c_dataset():
    ensure_db()
    _py("capture_database.py")

def train_d():
    _py("training_dataset.py")

def m_attendance():
    _py("recognizer.py")

def v_attendance():
    today = str(datetime.now().date())
    paths = [
        os.path.join(BASE, "Attendance_Files", f"Attendance{today}.xlsx"),
        os.path.join(BASE, "Attendance_Files", f"attendance{today}.xlsx"),
    ]
    for p in paths:
        if os.path.exists(p):
            os.startfile(p)
            return
    messagebox.showwarning("Not Found", "Today's attendance file not found.")

def d_dataset():
    _py("delete_database.py")

def destroy():
    root.destroy()

def link_pair():
    ensure_db()
    if not os.path.exists(os.path.join(BASE, "link_child_guardian.py")):
        messagebox.showerror("Missing file","link_child_guardian.py not found.")
        return
    _py("link_child_guardian.py")

def start_exit_verification():
    ensure_db()
    if not os.path.exists(os.path.join(BASE, "trainer","trainer.yml")):
        messagebox.showwarning("Train first","Train model first.")
        return
    if not os.path.exists(os.path.join(BASE,"exit_verifier.py")):
        messagebox.showerror("Missing file","exit_verifier.py not found.")
        return
    _py("exit_verifier.py")

main_frame = ttk.Frame(root, style="Card.TFrame")
main_frame.grid(row=1, column=0, sticky=NSEW, padx=(20,10), pady=10)
main_frame.columnconfigure(0, weight=1)
main_frame.columnconfigure(1, weight=1)

main_label = ttk.Label(main_frame, text="Attendance Operations",
                       style="Header.TLabel")
main_label.grid(row=0, column=0, columnspan=2, sticky=EW, pady=(10,20))

btn_create = ttk.Button(main_frame, text="Create Dataset",
                        style="Main.TButton", command=c_dataset)
btn_create.grid(row=1, column=0, sticky=EW, padx=15, pady=8)

btn_train = ttk.Button(main_frame, text="Train Dataset",
                       style="Main.TButton", command=train_d)
btn_train.grid(row=1, column=1, sticky=EW, padx=15, pady=8)

btn_mark = ttk.Button(main_frame, text="Mark Attendance",
                      style="Main.TButton", command=m_attendance)
btn_mark.grid(row=2, column=0, sticky=EW, padx=15, pady=8)

btn_view = ttk.Button(main_frame, text="View Attendance Sheet",
                      style="Main.TButton", command=v_attendance)
btn_view.grid(row=2, column=1, sticky=EW, padx=15, pady=8)
btn_delete = ttk.Button(
    main_frame,
    text="Delete All Data",
    command=d_dataset
)
btn_delete.grid(row=3, column=0, columnspan=2, sticky=EW, padx=15, pady=8)


kg_frame = ttk.Frame(root, style="Card.TFrame")
kg_frame.grid(row=1, column=1, sticky=NSEW, padx=(10,20), pady=10)
kg_frame.columnconfigure(0, weight=1)
kg_frame.columnconfigure(1, weight=1)

kg_label = ttk.Label(kg_frame, text="Kindergarten Pickup",
                     style="Header.TLabel")
kg_label.grid(row=0, column=0, columnspan=2, sticky=EW, pady=(10,20))

btn_link = ttk.Button(kg_frame, text="Link Child ↔ Guardian",
                      style="Main.TButton", command=link_pair)
btn_link.grid(row=1, column=0, columnspan=2, sticky=EW, padx=15, pady=8)

btn_exit_verify = ttk.Button(kg_frame, text="Start Exit Verification",
                             style="Main.TButton", command=start_exit_verification)
btn_exit_verify.grid(row=2, column=0, columnspan=2, sticky=EW, padx=15, pady=8)

exit_btn = ttk.Button(root, text="Exit",
                      style="Danger.TButton", command=destroy)
exit_btn.grid(row=2, column=0, columnspan=2, sticky=E, padx=20, pady=(10,20))

root.rowconfigure(1, weight=1)

root.mainloop()

