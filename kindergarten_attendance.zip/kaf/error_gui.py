from tkinter import *
from tkinter import ttk

def show_error(text="Some error occurred"):
    root = Tk()
    root.title("Error Message")
    root.geometry("300x150")
    root.configure(bg="#1f2933")
    root.resizable(False, False)

    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Popup.TButton",
                    font=("Segoe UI", 12),
                    padding=6,
                    foreground="white",
                    background="#2563eb",
                    borderwidth=0)
    style.map("Popup.TButton",
              background=[("active", "#1d4ed8")])

    style.configure("Popup.TLabel",
                    font=("Segoe UI", 12), 
                    background="#1f2933",
                    foreground="white")

    msg = ttk.Label(root, text=text, style="Popup.TLabel", anchor="center")
    msg.pack(pady=20)

    def close():
        root.destroy()

    btn = ttk.Button(root, text="OK", style="Popup.TButton", command=close)
    btn.pack(pady=5)

    root.mainloop()


if __name__ == "__main__":
    show_error()
