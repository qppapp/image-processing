import os, sqlite3

os.makedirs('database', exist_ok=True)
db = os.path.join('database', 'database.db')
conn = sqlite3.connect(db)
c = conn.cursor()

c.execute("""
CREATE TABLE IF NOT EXISTS students(
  UID TEXT PRIMARY KEY,
  student_name TEXT NOT NULL,
  attendance TEXT NOT NULL DEFAULT 'Absent'
)
""")

c.execute("""
CREATE TABLE IF NOT EXISTS people(
  UID TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  role TEXT CHECK(role IN ('child','guardian')) NOT NULL
)
""")

c.execute("""
CREATE TABLE IF NOT EXISTS links(
  child_uid TEXT NOT NULL,
  guardian_uid TEXT NOT NULL,
  relation TEXT DEFAULT 'authorized',
  PRIMARY KEY (child_uid, guardian_uid),
  FOREIGN KEY(child_uid) REFERENCES people(UID),
  FOREIGN KEY(guardian_uid) REFERENCES people(UID)
)
""")

c.execute("""
CREATE TABLE IF NOT EXISTS pickup_log(
  ts TEXT NOT NULL,
  child_uid TEXT NOT NULL,
  guardian_uid TEXT NOT NULL,
  status TEXT CHECK(status IN ('authorized','unauthorized')) NOT NULL,
  note TEXT
)
""")

conn.commit()
conn.close()

