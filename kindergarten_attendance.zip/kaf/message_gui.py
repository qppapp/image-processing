from tkinter import *
from tkinter import ttk

def show_message(text="Done"):
    win = Tk()
    win.title("Message")
    win.geometry("300x150")
    win.configure(background="#1f2933")   # same dark bg as firstpage_gui
    win.resizable(False, False)

    # ttk styling consistent with firstpage_gui.py
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Popup.TFrame", background="#111827")
    style.configure("Popup.TLabel",
                    font=("Segoe UI SemiBold", 14),
                    background="#1f2933",
                    foreground="white")
    style.configure("Popup.TButton",
                    font=("Segoe UI", 12),
                    padding=6,
                    foreground="white",
                    background="#2563eb",
                    borderwidth=0)
    style.map("Popup.TButton",
              background=[("active", "#1d4ed8")])

    frame = ttk.Frame(win, style="Popup.TFrame")
    frame.pack(expand=True, fill=BOTH, padx=20, pady=20)

    lbl = ttk.Label(frame, text=text, style="Popup.TLabel")
    lbl.pack(pady=(10, 20))

    def close():
        win.destroy()

    ok_btn = ttk.Button(frame, text="OK", style="Popup.TButton", command=close)
    ok_btn.pack()

    win.mainloop()


if __name__ == "__main__":
    show_message("Done")
