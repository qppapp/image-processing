import os
import sys
import time
import cv2
import numpy as np
import sqlite3 as sql

def open_db():
    conn = sql.connect("database/database.db")
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM students")
    total = cur.fetchone()[0]
    if total == 0:
        os.system("python error_gui.py")
        conn.close()
        sys.exit("No students in database.")
    return conn, cur

def recognize_loop(conn, cur):
    detector = cv2.CascadeClassifier("cascades/haarcascade_frontalface_default.xml")
    cam = cv2.VideoCapture(0)

    model = cv2.face.LBPHFaceRecognizer_create()
    model.read("trainer/trainer.yml")

    font = cv2.FONT_HERSHEY_SIMPLEX
    start = time.time()
    error_hits = 0
    duration = 15
    conf_limit = 80

    while True:
        ok, frame = cam.read()
        if not ok:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        boxes = detector.detectMultiScale(gray, 1.3, 7)

        for (x, y, w, h) in boxes:
            patch = gray[y:y+h, x:x+w]
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0))
            pred_id, conf = model.predict(patch)
            cv2.putText(frame, str(pred_id), (x, y - 10), font, 0.55, (120, 255, 120), 1)

            if conf < conf_limit:
                cur.execute("SELECT UID FROM students WHERE UID = ?", (str(pred_id),))
                row = cur.fetchone()
                if row is not None and row[0] == str(pred_id):
                    cur.execute(
                        "UPDATE students SET attendance = ? WHERE UID = ?",
                        ("Present", str(pred_id))
                    )
                    conn.commit()
                else:
                    os.system("python error_gui.py")
                    error_hits += 1
                    break

        cv2.imshow("Attendance", frame)

        if error_hits >= 10:
            os.system("python error_gui.py")
            break
        if time.time() - start > duration:
            break
        if cv2.waitKey(100) & 0xFF == ord("q"):
            break

    cam.release()
    cv2.destroyAllWindows()

def main():
    conn, cur = open_db()
    recognize_loop(conn, cur)
    conn.close()
    os.system("python Marking_attendance.py")

if __name__ == "__main__":
    main()


