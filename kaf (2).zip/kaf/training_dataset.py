import os
import cv2
import numpy as np
from PIL import Image

root_dir = os.getcwd()
data_dir = os.path.join(root_dir, "dataset")
trainer_dir = os.path.join(root_dir, "trainer")
model_file = os.path.join(trainer_dir, "trainer.yml")

try:
    cas_path = os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")
    if not os.path.exists(cas_path):
        cas_path = os.path.join(root_dir, "cascades", "haarcascade_frontalface_default.xml")
except Exception:
    cas_path = os.path.join(root_dir, "cascades", "haarcascade_frontalface_default.xml")

os.makedirs(trainer_dir, exist_ok=True)

recognizer = cv2.face.LBPHFaceRecognizer_create(radius=1, neighbors=8, grid_x=8, grid_y=8)
cascade = cv2.CascadeClassifier(cas_path)

def normalize_face(gray_roi):
    eq = cv2.equalizeHist(gray_roi)
    return cv2.resize(eq, (200, 200), interpolation=cv2.INTER_AREA)

def load_faces_and_ids(folder):
    files = [os.path.join(folder, f) for f in os.listdir(folder)]
    samples = []
    labels = []

    for path in files:
        if not path.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff")):
            continue

        name_parts = os.path.basename(path).split(".")
        if len(name_parts) < 3:
            continue

        try:
            person_id = int(name_parts[1])
        except Exception:
            continue

        img = Image.open(path).convert("L")
        gray = np.array(img, "uint8")

        faces = cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5, minSize=(80, 80))
        for (x, y, w, h) in faces:
            face_roi = gray[y:y+h, x:x+w]
            samples.append(normalize_face(face_roi))
            labels.append(person_id)

    return samples, labels

faces, ids = load_faces_and_ids(data_dir)

if not faces:
    raise SystemExit("No valid faces found in dataset/. Capture images first (User.<UID>.<N>.jpg).")

recognizer.train(faces, np.array(ids))
recognizer.write(model_file)

print(f"Trained model saved to: {model_file}")
print(f"Number of samples: {len(faces)} | Distinct IDs: {len(set(ids))}")

msg_script = os.path.join(root_dir, "message_gui.py")
if os.path.exists(msg_script):
    os.system(f'python "{msg_script}"')

