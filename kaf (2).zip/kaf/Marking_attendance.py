
import os, sqlite3 as sql
from datetime import datetime
from openpyxl import Workbook

BASE = os.getcwd()
ATT_DIR = os.path.join(BASE, "Attendance_Files")
os.makedirs(ATT_DIR, exist_ok=True)
TODAY = str(datetime.now().date())
ATT_PATH = os.path.join(ATT_DIR, f"Attendance{TODAY}.xlsx")

DB = os.path.join(BASE, 'database', 'database.db')
conn = sql.connect(DB); c = conn.cursor()
c.execute("SELECT UID, student_name, attendance FROM students ORDER BY student_name")
rows = c.fetchall(); conn.close()

wb = Workbook(); ws = wb.active
ws.append(["UID", "Name", "Attendance"])
for r in rows: ws.append(r)
wb.save(ATT_PATH)
print("Saved:", ATT_PATH)
