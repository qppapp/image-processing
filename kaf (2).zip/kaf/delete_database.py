import os
import shutil
import sqlite3 as sql
from tkinter import messagebox, Tk

BASE = os.getcwd()

DATASET_DIR = os.path.join(BASE, "dataset")
TRAINER_FILE = os.path.join(BASE, "trainer", "trainer.yml")
ATTENDANCE_DIR = os.path.join(BASE, "Attendance_Files")
DB_PATH = os.path.join(BASE, "database", "database.db")


root = Tk()
root.withdraw()   

confirm = messagebox.askyesno(
    "Confirm Deletion",
    "This will delete:\n\n"
    "- ALL face images (dataset)\n"
    "- Trained model (trainer.yml)\n"
    "- Attendance files\n"
    "- ALL database records \n\n"
    "Are you sure?"
)

if not confirm:
    messagebox.showinfo("Cancelled", "Deletion cancelled.")
    root.destroy()
    raise SystemExit()

root.destroy()

if os.path.exists(DATASET_DIR):
    try:
        shutil.rmtree(DATASET_DIR)
        print("Deleted dataset folder:", DATASET_DIR)
    except Exception as e:
        print("Error deleting dataset:", e)



if os.path.exists(TRAINER_FILE):
    try:
        os.remove(TRAINER_FILE)
        print("Deleted trainer model:", TRAINER_FILE)
    except Exception as e:
        print("Error deleting trainer model:", e)


if os.path.exists(ATTENDANCE_DIR):
    try:
        shutil.rmtree(ATTENDANCE_DIR)
        print("Deleted attendance files folder:", ATTENDANCE_DIR)
    except Exception as e:
        print("Error deleting attendance files:", e)

if os.path.exists(DB_PATH):
    try:
        conn = sql.connect(DB_PATH)
        c = conn.cursor()
        c.execute("DELETE FROM students")
        c.execute("DELETE FROM people")
        c.execute("DELETE FROM links")
        c.execute("DELETE FROM pickup_log")
        conn.commit()
        conn.close()
        print("Cleared all database tables.")
    except Exception as e:
        print("Error clearing database:", e)
else:
    print("Database file not found, skipping DB reset.")


print("\nAll data successfully deleted.")
