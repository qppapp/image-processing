import os, time, cv2, sqlite3 as sql
from datetime import datetime

BASE = os.getcwd()
DB = os.path.join(BASE,'database','database.db')
CASCADE = os.path.join(cv2.data.haarcascades,"haarcascade_frontalface_default.xml")
TRAINER = os.path.join(BASE,'trainer','trainer.yml')

THRESH = 75
PAIR_WINDOW_SEC = 10

def prep(gray_roi):
    eq = cv2.equalizeHist(gray_roi)
    return cv2.resize(eq,(200,200),interpolation=cv2.INTER_AREA)

con = sql.connect(DB); c = con.cursor()

def is_linked(child_uid, guardian_uid):
    c.execute("SELECT 1 FROM links WHERE child_uid=? AND guardian_uid=?",(child_uid,guardian_uid))
    return c.fetchone() is not None

def log_pickup(child_uid, guardian_uid, status, note=""):
    ts = datetime.now().isoformat(timespec='seconds')
    c.execute("INSERT INTO pickup_log(ts,child_uid,guardian_uid,status,note) VALUES(?,?,?,?,?)",
              (ts,child_uid,guardian_uid,status,note))
    con.commit()

face_cas = cv2.CascadeClassifier(CASCADE)
recognizer = cv2.face.LBPHFaceRecognizer_create(); recognizer.read(TRAINER)

cap = cv2.VideoCapture(0)
font = cv2.FONT_HERSHEY_SIMPLEX
last = {"child": None, "guardian": None, "t": 0}

print("Exit gate active: present child + authorized guardian within 10s.")

while True:
    ret, img = cap.read()
    if not ret: break
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cas.detectMultiScale(gray, 1.2, 5, minSize=(80,80))
    now = time.time()
    if now - last["t"] > PAIR_WINDOW_SEC:
        last = {"child": None, "guardian": None, "t": now}

    for (x,y,w,h) in faces:
        roi = prep(gray[y:y+h, x:x+w])
        uid, conf = recognizer.predict(roi)
        color = (0,255,0) if conf<THRESH else (0,0,255)
        label = "Unknown"

        if conf < THRESH:
            uid_str = str(uid)
            c.execute("SELECT role,name FROM people WHERE UID=?", (uid_str,))
            row = c.fetchone()
            if row:
                role, name = row
                label = f"{role}:{name} ({uid})"
                if role in ("child","guardian"):
                    last[role] = uid_str
                    last["t"] = now

        cv2.rectangle(img,(x,y),(x+w,y+h),color,2)
        cv2.putText(img,label,(x,y-10),font,0.55,color,2)

    if last["child"] and last["guardian"]:
        if is_linked(last["child"], last["guardian"]):
            msg = f"AUTHORIZED: child {last['child']} with guardian {last['guardian']}"
            log_pickup(last["child"], last["guardian"], "authorized", msg)
            cv2.putText(img,"AUTHORIZED ✔",(10,30),font,0.9,(0,200,0),3)
        else:
            msg = f"UNAUTHORIZED: child {last['child']} with guardian {last['guardian']}"
            log_pickup(last["child"], last["guardian"], "unauthorized", msg)
            cv2.putText(img,"BLOCKED ✖",(10,30),font,0.9,(0,0,255),3)
        last = {"child": None, "guardian": None, "t": now}

    cv2.imshow("Exit Verification (ESC to quit)", img)
    
    if (cv2.waitKey(30) & 0xFF) == 27:  # ESC KEY
        break

cap.release()
cv2.destroyAllWindows()
con.close()
