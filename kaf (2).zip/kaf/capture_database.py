import os
import cv2
import sqlite3
from tkinter import *
from tkinter import ttk, messagebox

root = Tk()
root.title("Create Dataset")
root.geometry("420x200")
root.configure(bg="#1f2933")

style = ttk.Style()
style.theme_use("clam")
style.configure("Main.TButton",
                font=("Segoe UI", 12),
                padding=6,
                foreground="white",
                background="#2563eb",
                borderwidth=0)
style.map("Main.TButton", background=[("active", "#1d4ed8")])
style.configure("Input.TLabel",
                font=("Segoe UI", 11),
                background="#1f2933",
                foreground="white")

root.columnconfigure(1, weight=1)

lbl_id = ttk.Label(root, text="Enter Your ID:", style="Input.TLabel")
lbl_name = ttk.Label(root, text="Enter Your Full Name:", style="Input.TLabel")
lbl_role = ttk.Label(root, text="Role:", style="Input.TLabel")

inp_id = ttk.Entry(root, width=25)
inp_name = ttk.Entry(root, width=25)

role_var = StringVar()
inp_role = ttk.Combobox(root, textvariable=role_var,
                        values=["child", "guardian"], state="readonly")

inp_role.set("")

lbl_id.grid(row=0, column=0, padx=8, pady=6, sticky=E)
inp_id.grid(row=0, column=1, padx=8, pady=6, sticky=E+W)
lbl_name.grid(row=1, column=0, padx=8, pady=6, sticky=E)
inp_name.grid(row=1, column=1, padx=8, pady=6, sticky=E+W)
lbl_role.grid(row=2, column=0, padx=8, pady=6, sticky=E)
inp_role.grid(row=2, column=1, padx=8, pady=6, sticky=E+W)

u_id = None
u_name = None
u_role = None


def submit_form():
    global u_id, u_name, u_role
    u_id = inp_id.get().strip()
    u_name = inp_name.get().strip()
    u_role = role_var.get().lower().strip()

    if not u_id or not u_name:
        messagebox.showerror("Error", "All fields must be filled.")
        return

    root.destroy()


btn = ttk.Button(root, text="Submit", command=submit_form, style="Main.TButton")
btn.grid(row=3, column=0, columnspan=2, padx=8, pady=10, sticky=E+W)

root.mainloop()

if not u_id or not u_name:
    raise SystemExit()

base = os.getcwd()
db_file = os.path.join(base, "database", "database.db")
images_dir = os.path.join(base, "dataset")
debug_out = os.path.join(base, "debug_results")
cascade_fallback = os.path.join(base, "cascades", "haarcascade_frontalface_default.xml")

for p in (images_dir, debug_out):
    os.makedirs(p, exist_ok=True)

if not os.path.exists(db_file):
    os.makedirs(os.path.dirname(db_file), exist_ok=True)
    os.system(f'python "{os.path.join(base, "sql.py")}"')

db = sqlite3.connect(db_file)
cur = db.cursor()

if u_role in ("child", ""):
    cur.execute(
        "INSERT OR REPLACE INTO students(UID, student_name, attendance) VALUES(?,?,?)",
        (u_id, u_name, "Absent")
    )
    db.commit()

if u_role in ("child", "guardian"):
    cur.execute(
        "INSERT OR REPLACE INTO people(UID, name, role) VALUES(?,?,?)",
        (u_id, u_name, u_role)
    )
    db.commit()

cam = cv2.VideoCapture(0)
cascade_path = os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")
if not os.path.exists(cascade_path):
    cascade_path = cascade_fallback

face_model = cv2.CascadeClassifier(cascade_path)

img_count = 0
limit = 30

while True:
    ret, frame = cam.read()
    if not ret:
        break

    g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    detected = face_model.detectMultiScale(g, 1.3, 5)

    for (x, y, w, h) in detected:
        img_count += 1

        col = frame[y:y+h, x:x+w]
        gray_cut = g[y:y+h, x:x+w]
        eq = cv2.equalizeHist(gray_cut)
        fixed = cv2.resize(eq, (200, 200), interpolation=cv2.INTER_AREA)

        cv2.imwrite(os.path.join(debug_out, f"{u_id}_orig_{img_count}.jpg"), col)
        cv2.imwrite(os.path.join(debug_out, f"{u_id}_gray_{img_count}.jpg"), gray_cut)
        cv2.imwrite(os.path.join(debug_out, f"{u_id}_equalized_{img_count}.jpg"), eq)
        cv2.imwrite(os.path.join(debug_out, f"{u_id}_resized_{img_count}.jpg"), fixed)

        fname = f"User.{u_id}.{img_count}.jpg"
        cv2.imwrite(os.path.join(images_dir, fname), gray_cut)

        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

    cv2.imshow("Capture Dataset (q to quit)", frame)

    key = cv2.waitKey(100)
    if key & 0xFF == ord("q"):
        break
    if img_count >= limit:
        messagebox.showinfo("Done", f"{limit} face samples recorded for ID {u_id}.")
        break

cam.release()
cv2.destroyAllWindows()
db.close()

