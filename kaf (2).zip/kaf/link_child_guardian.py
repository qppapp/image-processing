import os, sqlite3 as sql
DB = os.path.join(os.getcwd(), 'database', 'database.db')
con = sql.connect(DB); c = con.cursor()

child = input("Child UID: ").strip()
guardian = input("Guardian UID: ").strip()
relation = input("Relation (mother/father/nanny) [optional]: ").strip() or "authorized"

c.execute("SELECT role,name FROM people WHERE UID=?", (child,))
cr = c.fetchone()
c.execute("SELECT role,name FROM people WHERE UID=?", (guardian,))
gr = c.fetchone()

assert cr and cr[0]=='child', "Child UID not found or not a child."
assert gr and gr[0]=='guardian', "Guardian UID not found or not a guardian."

c.execute("INSERT OR IGNORE INTO links(child_uid,guardian_uid,relation) VALUES(?,?,?)",
          (child, guardian, relation))
con.commit(); con.close()
print(f"Linked child {child} ⇄ guardian {guardian} ({relation})")
